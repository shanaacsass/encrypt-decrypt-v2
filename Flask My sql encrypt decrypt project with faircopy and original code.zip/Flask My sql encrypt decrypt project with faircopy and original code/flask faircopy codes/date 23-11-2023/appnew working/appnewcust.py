from cryptography.fernet import Fernet
from flask import request, redirect, url_for, flash
from datetime import datetime

# Assuming you have already initialized Fernet with a secret key

@app.route("/assign_assets", methods=['GET', 'POST'])
def assign_assets():
    if request.method == 'POST':
        if 'assign' in request.form:
            customer_id = request.form["customer_id"]
            asset_ids = request.form.getlist("asset_id[]")

            # Fetch customer details and encryption_key based on customer_id
            cur = mysql.connection.cursor()
            cur.execute("SELECT customer_name, encryption_key FROM customers WHERE customer_id=%s", [customer_id])
            customer_details = cur.fetchone()

            if customer_details:
                try:
                    # Create Fernet objects with the existing and new encryption keys
                    encryption_key_customer = customer_details['encryption_key']
                    fernet_customer = Fernet(encryption_key_customer)

                    new_encryption_key = Fernet.generate_key()
                    fernet_assigned_customer = Fernet(new_encryption_key)

                    # Decrypt and encrypt customer_name
                    decrypted_customer_name = fernet_customer.decrypt(customer_details["customer_name"].encode()).decode('utf-8')
                    encrypted_customer_name = fernet_assigned_customer.encrypt(decrypted_customer_name.encode()).decode('utf-8')

                    # Insert assignment details into assigned_assets_customers table for each selected asset
                    for asset_id in asset_ids:
                        # Fetch asset details and encryption_key based on asset_id
                        cur.execute("SELECT asset_name, asset_description, encryption_key FROM it_assets WHERE asset_id=%s", [asset_id])
                        asset_details = cur.fetchone()

                        if asset_details:
                            encryption_key_asset = asset_details['encryption_key']
                            fernet_asset = Fernet(encryption_key_asset)

                            # Decrypt asset details
                            decrypted_asset_name = fernet_asset.decrypt(asset_details["asset_name"].encode()).decode('utf-8')
                            decrypted_asset_description = fernet_asset.decrypt(asset_details["asset_description"].encode()).decode('utf-8')

                            # Encrypt asset details with a new key
                            new_encryption_key_asset = Fernet.generate_key()
                            fernet_assigned_asset = Fernet(new_encryption_key_asset)

                            encrypted_asset_name = fernet_assigned_asset.encrypt(decrypted_asset_name.encode()).decode('utf-8')
                            encrypted_asset_description = fernet_assigned_asset.encrypt(decrypted_asset_description.encode()).decode('utf-8')

                            # Insert into assigned_assets_customers table
                            cur.execute('INSERT INTO assigned_assets_customers (customer_id, asset_id, assignment_date, customer_name, customer_email, customer_address, asset_name, asset_description, encryption_key) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)',
                                        [customer_id, asset_id, datetime.now(), encrypted_customer_name, customer_details["customer_email"], customer_details["customer_address"], encrypted_asset_name, encrypted_asset_description, new_encryption_key_asset])

                    mysql.connection.commit()
                    cur.close()

                    flash('Assets assigned successfully', 'success')
                    return redirect(url_for('view_assigned_assets'))  # Redirect to the view_assigned_assets page
                except Exception as e:
                    print(e)
                    flash('Error assigning assets', 'danger')

    # Rest of the code
    # Fetch customer and asset data and pass it to the template

    return render_template("assign_assets.html", customer_data=customer_data, asset_data=asset_data)
