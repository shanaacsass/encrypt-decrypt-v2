# Edit assigned asset and update when we click the update button means it will update page was edit_
@app.route("/edit_assigned_asset/<int:assignment_id>", methods=['GET', 'POST'])
def edit_assigned_asset(assignment_id):
    if request.method == 'POST':
        if 'update' in request.form:
            try:
                # Extract form data
                customer_id = request.form["customer_id"]
                asset_id = request.form["asset_id"]
                asset_name = request.form["asset_name"]
                asset_description = request.form["asset_description"]
                # Add additional fields as needed
                # ...

                # Update the assigned_assets_customers table
                cur = mysql.connection.cursor()
                cur.execute('UPDATE assigned_assets_customers SET customer_id=%s, asset_id=%s, asset_name=%s, asset_description=%s WHERE assignment_id=%s',
                            [customer_id, asset_id, asset_name, asset_description, assignment_id])
                mysql.connection.commit()
                cur.close()

                flash('Asset updated successfully', 'success')
                return redirect(url_for('view_assigned_assets'))

            except Exception as e:
                print(e)
                flash('Error updating asset', 'danger')