# Insert assignment details into assigned_assets_customers table for each selected asset
@app.route("/assign_assets", methods=['GET', 'POST'])
def assign_assets():
    if request.method == 'POST':
        if 'assign' in request.form:
            customer_id = request.form["customer_id"]
            asset_ids = request.form.getlist("asset_id[]")

            # Fetch customer details and encryption_key based on customer_id
            cur = mysql.connection.cursor()
            cur.execute("SELECT customer_name, customer_address, customer_email, encryption_key FROM customers WHERE customer_id=%s", [customer_id])
            customer_details = cur.fetchone()

            if customer_details:
                try:
                    # Create Fernet objects with the existing encryption keys for customer
                    encryption_key_customer = customer_details['encryption_key']  # Load the existing encryption key from the customers table
                    fernet_customer = Fernet(encryption_key_customer)  # Create a Fernet object based on the loaded encryption key

                    # Use a common encryption key for all assets assigned to the customer
                    new_encryption_key_asset = Fernet.generate_key()  # Generate a new encryption key
                    fernet_assigned_asset = Fernet(new_encryption_key_asset)  # Store the generated encryption key in a Fernet object

                    # Decrypt and encrypt customer_name
                    decrypted_customer_name = fernet_customer.decrypt(customer_details["customer_name"].encode()).decode('utf-8')  # Decrypt customer_name
                    encrypted_customer_name = fernet_assigned_asset.encrypt(decrypted_customer_name.encode()).decode('utf-8')  # Encrypt customer_name for inserting into the customer_name column in the assigned_assets_customer table

                    # Encrypt customer_email with the common encryption key
                    encrypted_customer_email = fernet_assigned_asset.encrypt(customer_details["customer_email"].encode()).decode('utf-8')

                    # Handle customer_address
                    if customer_details["customer_address"]:  # Check if customer_address is not empty
                        # Decrypt and encrypt customer_address
                        decrypted_customer_address = fernet_customer.decrypt(customer_details["customer_address"].encode()).decode('utf-8')
                        encrypted_customer_address = fernet_assigned_asset.encrypt(decrypted_customer_address.encode()).decode('utf-8')
                    else:
                        # If customer_address is empty, insert as empty
                        encrypted_customer_address = ""

                    # Insert assignment details into assigned_assets_customers table for each selected asset
                    for asset_id in asset_ids:
                        # Fetch asset details and encryption_key based on asset_id
                        cur.execute("SELECT asset_name, asset_description, encryption_key FROM it_assets WHERE asset_id=%s", [asset_id])
                        asset_details = cur.fetchone()

                        if asset_details:
                            # Create Fernet object with the existing encryption key for the asset
                            encryption_key_asset = asset_details['encryption_key']
                            fernet_asset = Fernet(encryption_key_asset)

                            # Decrypt asset details
                            decrypted_asset_name = fernet_asset.decrypt(asset_details["asset_name"].encode()).decode('utf-8')
                            decrypted_asset_description = fernet_asset.decrypt(asset_details["asset_description"].encode()).decode('utf-8')

                            # Encrypt asset details with the common encryption key stored in the fernet_assigned_asset object
                            encrypted_asset_name = fernet_assigned_asset.encrypt(decrypted_asset_name.encode()).decode('utf-8')
                            encrypted_asset_description = fernet_assigned_asset.encrypt(decrypted_asset_description.encode()).decode('utf-8')

                            # Insert into assigned_assets_customers table
                            cur.execute('INSERT INTO assigned_assets_customers (customer_id, asset_id, assignment_date, customer_name, customer_email, customer_address, asset_name, asset_description, encryption_key) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)',
                                        [customer_id, asset_id, datetime.now(), encrypted_customer_name, encrypted_customer_email, encrypted_customer_address, encrypted_asset_name, encrypted_asset_description, new_encryption_key_asset])

                    mysql.connection.commit()
                    cur.close()

                    flash('Assets assigned successfully', 'success')
                    return redirect(url_for('view_assigned_assets'))  # Redirect to the view_assigned_assets page
                except Exception as e:
                    print(e)
                    # Print the traceback for more detailed error information
                    import traceback
                    traceback.print_exc()

                    flash('Error assigning assets', 'danger')