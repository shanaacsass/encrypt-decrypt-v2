# Insert assignment details into assigned_assets_customers table for each selected asset
@app.route("/assign_assets", methods=['GET', 'POST'])
def assign_assets():
    if request.method == 'POST':
        if 'assign' in request.form:
            customer_id = request.form["customer_id"]
            asset_ids = request.form.getlist("asset_id[]")

            # Fetch customer details and encryption key based on customer_id
            cur = mysql.connection.cursor()
            cur.execute("SELECT customer_name, customer_email, customer_address, encryption_key FROM customers WHERE customer_id=%s", [customer_id])
            customer_details = cur.fetchone()

            if customer_details:
                try:
                    # Fetch existing assets for this  customer
                    cur.execute("SELECT asset_name, asset_description, encryption_key FROM it_assets WHERE asset_id=%s", [asset_ids])
                    assets_details = cur.fetchall()
                    # Generate a new encryption key for assigned_assets_customers
                    new_encryption_key = Fernet.generate_key()
                    fernet_assigned_assets = Fernet(new_encryption_key)

                    
                    # Insert assignment details into assigned_assets_customers table for each selected asset
                    for asset_details in assets_details:
                        # Decrypt customer details
                        encryption_key = customer_details['encryption_key']
                        fernet_customer = Fernet(encryption_key)
                        decrypted_customer_name = fernet_customer.decrypt(customer_details['customer_name'].encode()).decode('utf-8')
                        decrypted_customer_email = fernet_customer.decrypt(customer_details['customer_email'].encode()).decode('utf-8')
                        decrypted_customer_address = fernet_customer.decrypt(customer_details['customer_address'].encode()).decode('utf-8')

                        # Decrypt asset details
                        encryption_key_asset = asset_details['encryption_key']
                        fernet_asset = Fernet(encryption_key_asset)
                        decrypted_asset_name = fernet_asset.decrypt(asset_details['asset_name'].encode()).decode('utf-8')
                        decrypted_asset_description = fernet_asset.decrypt(asset_details['asset_description'].encode()).decode('utf-8') 

                        # Encrypt details with new key for assigned_assets_customers
                        encrypted_customer_name = fernet_assigned_assets.encrypt(decrypted_customer_name.encode().decode('utf-8'))
                        encrypted_customer_email = fernet_assigned_assets.encrypt(decrypted_customer_email.encode().decode('utf-8'))
                        encrypted_customer_address = fernet_assigned_assets.encrypt(decrypted_customer_address.encode().decode('utf-8'))
                        encrypted_asset_name = fernet_assigned_assets.encrypt(decrypted_asset_name.encode().decode('utf-8'))
                        encrypted_asset_description = fernet_assigned_assets.encrypt(decrypted_asset_description.encode().decode('utf-8'))

                         # Get the asset_id for the assigned_assets_customers table
                        assigned_asset_id = asset_details['asset_id']

                        # Insert into assigned_assets_customers
                        cur.execute('INSERT INTO assigned_assets_customers (customer_id, asset_id, asset_name, asset_description, assignment_date, customer_name, customer_email, customer_address, encryption_key) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)',
                                    [customer_id, assigned_asset_id, encrypted_asset_name, encrypted_asset_description, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), encrypted_customer_name, encrypted_customer_email, encrypted_customer_address, new_encryption_key])
                    mysql.connection.commit()
                    cur.close()

                    flash('Assets assigned successfully', 'success')
                    return redirect(url_for('view_assigned_assets')) # Redirect to the view_assigned_assets.page

                except Exception as e:
                    print(e)
                    flash('Error assigning assets', 'danger')
                        