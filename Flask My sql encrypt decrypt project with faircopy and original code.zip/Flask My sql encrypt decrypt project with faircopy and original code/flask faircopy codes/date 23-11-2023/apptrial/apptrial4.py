# Fetch data from the assigned_assets_customers table in view_assigned_assets.html page
@app.route("/view_assigned_assets")
def view_assigned_assets():
    try:
        # Fetch data from the assigned_assets_customers table
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM assigned_assets_customers")
        assigned_assets_data = cur.fetchall()

        # Decrypt encrypted values using the encryption keys
        decrypted_assets_data = []
        for asset_data in assigned_assets_data:
            # Decrypt customer_name
            encryption_key_customer = asset_data['encryption_key']
            fernet_customer = Fernet(encryption_key_customer)
            decrypted_customer_name = fernet_customer.decrypt(asset_data['customer_name'].encode()).decode('utf-8')
            
            # Decrypt customer_email (assuming it's not encrypted, as mentioned earlier)
            decrypted_customer_email = asset_data['customer_email']

            # Decrypt customer_address
            if asset_data['customer_address']:
                decrypted_customer_address = fernet_customer.decrypt(asset_data['customer_address'].encode()).decode('utf-8')
            else:
                decrypted_customer_address = ''

            # Decrypt asset_name and asset_description
            encryption_key_asset = asset_data['encryption_key']
            fernet_asset = Fernet(encryption_key_asset)
            decrypted_asset_name = fernet_asset.decrypt(asset_data['asset_name'].encode()).decode('utf-8')
            decrypted_asset_description = fernet_asset.decrypt(asset_data['asset_description'].encode()).decode('utf-8')

            # Create a new dictionary with decrypted values
            decrypted_data_entry = {
                'assignment_id': asset_data['assignment_id'],
                'customer_id': asset_data['customer_id'],
                'asset_id': asset_data['asset_id'],
                'asset_name': decrypted_asset_name,
                'asset_description': decrypted_asset_description,
                'assignment_date': asset_data['assignment_date'],
                'customer_name': decrypted_customer_name,
                'customer_email': decrypted_customer_email,
                'customer_address': decrypted_customer_address,
            }

            decrypted_assets_data.append(decrypted_data_entry)

        cur.close()

        return render_template("view_assigned_assets.html", assigned_assets_data=decrypted_assets_data)

    except Exception as e:
        print(e)
        flash('Error fetching assigned assets data', 'danger')

    return render_template("view_assigned_assets.html", assigned_assets_data=[])
