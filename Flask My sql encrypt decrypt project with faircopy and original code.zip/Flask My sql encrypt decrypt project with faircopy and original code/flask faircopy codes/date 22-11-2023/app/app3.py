from flask import Flask,render_template,request,url_for,session,redirect,flash
from flask_mysqldb import MySQL
from flask_bcrypt import Bcrypt
from cryptography.fernet import Fernet
# Add this import at the top of your app.py file
from datetime import datetime

app=Flask(__name__)

app.config["MYSQL_HOST"]="localhost"
app.config["MYSQL_USER"]="root"
app.config["MYSQL_PASSWORD"]=""
app.config["MYSQL_DB"]="register"
app.config["MYSQL_CURSORCLASS"]="DictCursor"
mysql=MySQL(app)
bcrypt = Bcrypt(app)
# cipher text package
key = Fernet.generate_key()
cipher_suite = Fernet(key)
def decrypt_data(encrypted_data):
    try:
        decrypted_data = cipher_suite.decrypt(encrypted_data.encode()).decode('utf-8')
        return decrypted_data
    except Exception as e:
        print(f"Error decrypting data: {e}")
        return None
# @app.route("/")
# def index():
#     cur = mysql.connection.cursor()
#     cur.execute("select * from admin")
#     result = cur.fetchall()
#     return '<h1>'+str(result[0]["aid"])+'</h1>'
@app.route("/", methods=['GET','POST'])
def index():
    if 'alogin' in request.form:
        if request.method == 'POST':
            # aname = request.form["aname"]
            aemail = request.form["aemail"]
            apass = request.form["apass"]
            try:
                cur = mysql.connection.cursor()
                cur.execute("select * from admin where aemail=%s and apass=%s", [aemail, apass])
                res = cur.fetchone()
                if res:
                    session["aname"] = res["aname"]
                    session["aid"] = res["aid"]
                    return redirect(url_for('admin_home'))
                else:
                    return render_template("index.html")
            except Exception as e:
                print(e)
            finally:
                mysql.connection.commit()
                cur.close()
    elif 'register' in request.form:
        if request.method == 'POST':
            # Inside your registration logic
            encryption_key = Fernet.generate_key()
            fernet = Fernet(encryption_key)
            uname = request.form["uname"]
            password = request.form["upass"]
            hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')  # Hash the password
            age = request.form["age"]
            address = request.form["address"]
            # Encrypt age and address and uname
            encrypted_uname = fernet.encrypt(uname.encode()).decode('utf-8')
            encrypted_age = fernet.encrypt(age.encode()).decode('utf-8')
            encrypted_address = fernet.encrypt(address.encode()).decode('utf-8')
            mail = request.form["mail"]
            cur = mysql.connection.cursor()
            cur.execute('INSERT INTO customers (customer_name, customer_password, customer_age, customer_address, customer_email, encryption_key) VALUES (%s, %s, %s, %s, %s, %s)', [encrypted_uname, hashed_password, encrypted_age, encrypted_address, mail, encryption_key])
            mysql.connection.commit()
        return render_template("index.html")
    
    # customers login based on customers email id and password which was created by admin 
    elif 'ulogin' in request.form:
        if request.method == 'POST':
            Customeremail = request.form["customeremail"]
            Customerpassword = request.form["customerpassword"]
            try:
                cur = mysql.connection.cursor()
                cur.execute("SELECT * FROM customers WHERE customer_email=%s", [Customeremail])
                res = cur.fetchone()
                if res and bcrypt.check_password_hash(res["customer_password"], Customerpassword):
                    # Load the encryption key from the customers table
                    encryption_key = res["encryption_key"]
                    fernet = Fernet(encryption_key)
                     # Decrypt the customer_name
                    decrypted_customer_name = fernet.decrypt(res["customer_name"].encode()).decode('utf-8')
                    session["customeremail"] = res["customer_email"]
                    session["customername"] = decrypted_customer_name
                    session["Customerid"] = res["customer_id"]
                    return redirect(url_for('user_home'))
                else:
                    return render_template("index.html")
            except Exception as e:
                print(e)
            finally:
                cur.close()
                mysql.connection.commit()

    return render_template("index.html")

# customers fetching on customers login in user_profile.html
@app.route("/user_profile")
def user_profile():
    id = session["Customerid"]  # Get the Customer ID from the session   
    qry = "SELECT * FROM customers WHERE customer_id=%s"  # Query to fetch user data based on the Customer ID  
    cur = mysql.connection.cursor() # Execute the query with the Customer ID parameter this line and 2nd line
    cur.execute(qry, [id])
    user_data = cur.fetchone() # Fetch the user data as a dictionary  
    cur.close()   # Close the database cursor

    # Check if user data is not found
    if not user_data:
        flash("User Not Found...!!!", "danger") # Display a flash message if user not found
        return render_template("user_profile.html", res=None) # Pass None to the template to handle non-existent user gracefully
    
    
    encryption_key = user_data["encryption_key"] # Load the encryption key from the customers table
    fernet = Fernet(encryption_key) # Create a Fernet object with the loaded encryption key

    # Decrypt age and address
    decrypted_name = fernet.decrypt(user_data["customer_name"].encode()).decode('utf-8')
    decrypted_age = fernet.decrypt(user_data["customer_age"].encode()).decode('utf-8') if user_data["customer_age"] else ''  #if user_data["customer_age"] else ''  I add these code because if admin register means this field was empty so if writtenthis code means the empty value also render and display otherwise it show error
    decrypted_address = fernet.decrypt(user_data["customer_address"].encode()).decode('utf-8') if user_data["customer_address"] else '' #if user_data["customer_age"] else ''  I add these code because if admin register means this field was empty so if writtenthis code means the empty value also render and display otherwise it show error

    # Pass the decrypted data and original user data to the user_profile.html template
    return render_template("user_profile.html", user_data=user_data, decrypted_age=decrypted_age, decrypted_address=decrypted_address, decrypted_name=decrypted_name)



# customers login and update
@app.route("/update_user", methods=['GET', 'POST'])
def update_user():
    if request.method == 'POST':
        name = request.form['name']
        password = request.form['password']
        age = request.form['age']
        address = request.form['address']
        mail = request.form['mail']
        Customerid = session["Customerid"]

        # Generate a new encryption key
        encryption_key = Fernet.generate_key()
        fernet = Fernet(encryption_key)

        cur = mysql.connection.cursor()

        if password:  # Check if password is provided
            # Hash the password
            hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
            
            # Encrypt age and address
            encrypted_name = fernet.encrypt(name.encode()).decode('utf-8')
            encrypted_age = fernet.encrypt(age.encode()).decode('utf-8')
            encrypted_address = fernet.encrypt(address.encode()).decode('utf-8')

            cur.execute("UPDATE customers SET customer_name=%s, customer_password=%s, customer_age=%s, customer_address=%s, customer_email=%s, encryption_key=%s WHERE customer_id=%s",
                        [encrypted_name, hashed_password, encrypted_age, encrypted_address, mail, encryption_key, Customerid])
        else:
            # Encrypt age and address
            encrypted_name = fernet.encrypt(name.encode()).decode('utf-8')
            encrypted_age = fernet.encrypt(age.encode()).decode('utf-8')
            encrypted_address = fernet.encrypt(address.encode()).decode('utf-8')

            cur.execute("UPDATE customers SET customer_name=%s, customer_age=%s, customer_address=%s, customer_email=%s, encryption_key=%s WHERE customer_id=%s",
                        [encrypted_name, encrypted_age, encrypted_address, mail, encryption_key, Customerid])

        mysql.connection.commit()
        flash('User Updated Successfully', 'success')
        return redirect(url_for('user_profile'))

    return render_template("user_profile.html")

# admin register for customers email and password and username.. (admin can create customers email, name and password)
@app.route("/admin_home", methods=['GET', 'POST'])
def admin_home():
    adminname = session.get("aname")

    if request.method == 'POST' and 'register' in request.form:
        # Handle user registration
        Customername = request.form["customername"]
        Customeremail = request.form["customeremail"]
        Customerpassword = request.form["customerpassword"]
        encryption_key = Fernet.generate_key()
        fernet = Fernet(encryption_key)
        # Encrypt the customer name
        encrypted_customername = fernet.encrypt(Customername.encode()).decode('utf-8')
        try:
            # Hash the password
            Customerhashedpassword = bcrypt.generate_password_hash(Customerpassword).decode('utf-8')
            # Insert the new user into the admin table
            cur = mysql.connection.cursor()
            cur.execute('INSERT INTO customers (customer_name, customer_email, customer_password, encryption_key) VALUES (%s, %s, %s, %s)', [encrypted_customername, Customeremail, Customerhashedpassword, encryption_key])
            mysql.connection.commit()
            cur.close()

            flash('User registered successfully', 'success')
            return redirect(url_for('admin_home'))

        except Exception as e:
            print(e)
            flash('Error registering user', 'danger')

    return render_template("admin_home.html", aname=adminname)


# Admin view existing customers from customers table
@app.route("/view_users")
def view_users():
    cur = mysql.connection.cursor()  # Initialize a database cursor
    qry = "SELECT * FROM customers"
    cur.execute(qry)
    data = cur.fetchall()  # Fetch all data from the query result
    cur.close()  # Close the database cursor
    count = len(data)  # Count the number of records fetched

    if count == 0:
        flash("Users not found...!!!", "danger")  # Display a flash message if no users are found

    # Decrypt customer names
    decrypted_data = []
    for user_data in data:
        # Decrypt the customer name
        decrypted_name = decrypt_customer_name(user_data['customer_name'], user_data['encryption_key'])  #green colour decrypt_customer_name is function we written function below 
        decrypted_age = decrypt_customer_field(user_data['customer_age'], user_data['encryption_key'])   #green colour decrypt_customer_field is function we written function below
        decrypted_address = decrypt_customer_field(user_data['customer_address'], user_data['encryption_key']) #green colour decrypt_customer_field is function we written function below
        user_data['decrypted_name'] = decrypted_name   # that user_data[decrypted_name] in yellow colour was stored in decrypted_name variable name it is white colour 
        user_data['decrypted_age'] = decrypted_age   
        user_data['decrypted_address'] = decrypted_address
        decrypted_data.append(user_data)

    return render_template("view_users.html", res=decrypted_data)  # Render the template with decrypted user data

# Function to decrypt customer name
def decrypt_customer_name(encrypted_name, encryption_key):
    fernet = Fernet(encryption_key)  # Create a Fernet object with the encryption key
    decrypted_name = fernet.decrypt(encrypted_name.encode()).decode('utf-8')  # Decrypt the customer name
    return decrypted_name

# Function to decrypt customer age and address  //why we written customer_name and customer_age is null means it display empty thats why i written in else condition because the admin register means the customer_address and customer_age field was saved as empty or blank because we dont give a input field for admin 
def decrypt_customer_field(encrypted_field, encryption_key):
    if encrypted_field:  # Check if the field is not empty
        fernet = Fernet(encryption_key)  # Create a Fernet object with the encryption key
        decrypted_field = fernet.decrypt(encrypted_field.encode()).decode('utf-8')  # Decrypt the field
        return decrypted_field
    else:
        return ''  # Return empty string if the field is empty

# admin delete customers data 
@app.route("/delete_users/<string:Customerid>", methods=['GET', 'POST'])
def delete_users(Customerid):
    cur = mysql.connection.cursor()
    cur.execute("delete from customers where customer_id=%s", [Customerid])
    mysql.connection.commit()
    flash("Users Deleted Successfully", "danger")
    return redirect(url_for("view_users"))

# Admin update customers modal code
@app.route("/update_user_data/<string:Customerid>", methods=['POST'])
def update_user_data(Customerid):
    print("Updating user data for Customer ID:", Customerid)

    if request.method == 'POST':
        # Fetch data from the form
        update_name = request.form["update_name"]
        update_age = request.form["update_age"]
        update_address = request.form["update_address"]
        update_email = request.form["update_email"]
        update_password = request.form["update_password"]

        try:
            cur = mysql.connection.cursor()

            # Generate a new encryption key
            new_encryption_key = Fernet.generate_key()
            fernet = Fernet(new_encryption_key)

            # Check if the password field is not empty, then update the password
            if update_password:
                # Hash the password
                hashed_password = bcrypt.generate_password_hash(update_password).decode('utf-8')
                
                # Encrypt age and address
                encrypted_name = fernet.encrypt(update_name.encode()).decode('utf-8')
                encrypted_age = fernet.encrypt(update_age.encode()).decode('utf-8')
                encrypted_address = fernet.encrypt(update_address.encode()).decode('utf-8')

                cur.execute('UPDATE customers SET customer_name=%s, customer_age=%s, customer_address=%s, customer_email=%s, customer_password=%s, encryption_key=%s WHERE customer_id=%s',
                            [encrypted_name, encrypted_age, encrypted_address, update_email, hashed_password, new_encryption_key, Customerid])
            else:
                # Encrypt age and address
                encrypted_name = fernet.encrypt(update_name.encode()).decode('utf-8')
                encrypted_age = fernet.encrypt(update_age.encode()).decode('utf-8')
                encrypted_address = fernet.encrypt(update_address.encode()).decode('utf-8')

                cur.execute('UPDATE customers SET customer_name=%s, customer_age=%s, customer_address=%s, customer_email=%s, encryption_key=%s WHERE customer_id=%s',
                            [encrypted_name, encrypted_age, encrypted_address, update_email, new_encryption_key, Customerid])

            mysql.connection.commit()
            cur.close()

            print('User updated successfully')
            flash('User updated successfully', 'success')
        except Exception as e:
            print(e)
            print('Error updating user')
            flash('Error updating user', 'danger')

    return redirect(url_for('view_users'))


# add asset code
@app.route("/add_asset", methods=['POST'])
def add_asset():
    if request.method == 'POST':
        asset_name = request.form['asset_name']
        asset_description = request.form['asset_description']
        purchase_date = request.form['purchase_date']
        location = request.form['location']

        cur = mysql.connection.cursor()
        cur.execute('INSERT INTO it_assets (asset_name, asset_description, purchase_date, location) VALUES (%s, %s, %s, %s)',
                    [asset_name, asset_description, purchase_date, location])
        mysql.connection.commit()
        cur.close()

        flash('IT Asset added successfully', 'success')
        return redirect(url_for('admin_home'))

    return render_template("admin_home.html", aname=session.get("aname"))

# fetch assets  this code is view_assets for fetching 
@app.route("/view_assets")
def view_assets():
    # Fetch existing IT assets
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM it_assets")
    existing_assets = cur.fetchall()
    cur.close()

    return render_template("view_assets.html", existing_assets=existing_assets)

# Route to delete asset button in view_asset page to delete an IT asset
@app.route("/delete_asset/<int:asset_id>")
def delete_asset(asset_id):
    try:
        cur = mysql.connection.cursor()
        cur.execute("DELETE FROM it_assets WHERE asset_id = %s", [asset_id])
        mysql.connection.commit()
        cur.close()
        flash('IT Asset deleted successfully', 'success')
    except Exception as e:
        print(e)
        flash('Error deleting IT asset', 'danger')

    return redirect(url_for('view_assets'))

#edit assets for fetching values in edit form in edit_assets.html
@app.route("/edit_asset/<int:asset_id>", methods=['GET', 'POST'])
def edit_asset(asset_id):
    if request.method == 'POST':
        # Fetch data from the form
        update_asset_name = request.form["update_asset_name"]
        update_asset_description = request.form["update_asset_description"]
        update_purchase_date = request.form["update_purchase_date"]
        update_location = request.form["update_location"]

        try:
            cur = mysql.connection.cursor()

            # Update the IT asset based on the asset ID
            cur.execute('UPDATE it_assets SET asset_name=%s, asset_description=%s, purchase_date=%s, location=%s WHERE asset_id=%s',
                        [update_asset_name, update_asset_description, update_purchase_date, update_location, asset_id])

            mysql.connection.commit()
            cur.close()

            flash('IT Asset updated successfully', 'success')
        except Exception as e:
            print(e)
            flash('Error updating IT asset', 'danger')

        return redirect(url_for('view_assets'))

    # Fetch the details of the selected IT asset based on edit_assets.html
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM it_assets WHERE asset_id=%s", [asset_id])
    asset_details = cur.fetchone()
    cur.close()

    return render_template("edit_asset.html", asset_details=asset_details)

# Add this route after the admin_home route  this code for inserting code for help disk by customers side to raise query
@app.route("/help_desk", methods=['GET', 'POST'])
def help_desk():
    if request.method == 'POST':
        user_id = session.get("Customerid")  # Assuming you've stored the user ID in the session
        issue_description = request.form["issue_description"]
        priority = request.form["priority"]

        # Set the initial status to "Open"
        status = "Open"

        timestamp = datetime.now()

        try:
            cur = mysql.connection.cursor()
            cur.execute('INSERT INTO help_desk_tickets (user_id, issue_description, status, priority, timestamp) VALUES (%s, %s, %s, %s, %s)',
                        [user_id, issue_description, status, priority, timestamp])
            mysql.connection.commit()
            cur.close()

            flash('Help desk ticket submitted successfully', 'success')
            return redirect(url_for('user_home'))

        except Exception as e:
            print(e)
            flash('Error submitting help desk ticket', 'danger')

    return render_template("help_desk.html")

# this code is for fetching the All customers help_desk_tickets columns data  in view_help_desk_tickets.html page
@app.route("/view_help_desk_tickets")
def view_help_desk_tickets():
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM help_desk_tickets")
        help_desk_tickets_data = cur.fetchall()
        cur.close()

        return render_template("view_help_desk_tickets.html", help_desk_tickets=help_desk_tickets_data)

    except Exception as e:
        print(e)
        flash('Error fetching help desk tickets', 'danger')

    return render_template("view_help_desk_tickets.html", help_desk_tickets=[])


# this code is for when we click update button (button name= is update_ticket) if we click means it will pass with ticket_id to update_ticket.html page
@app.route("/update_ticket/<int:ticket_id>")
def update_ticket(ticket_id):
    # Fetch the ticket details based on the ticket ID
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM help_desk_tickets WHERE ticket_id=%s", [ticket_id])
    ticket_details = cur.fetchone()
    cur.close()

    return render_template("update_ticket.html", ticket_details=ticket_details)

# based on ticket id the admin can update the status of tickets for customers status  in  update_ticket.html page
@app.route("/process_update_ticket/<int:ticket_id>", methods=['POST'])
def process_update_ticket(ticket_id):
    if request.method == 'POST':
        new_status = request.form['status']

        try:
            cur = mysql.connection.cursor()
            cur.execute('UPDATE help_desk_tickets SET status=%s WHERE ticket_id=%s', [new_status, ticket_id])
            mysql.connection.commit()
            cur.close()

            flash('Help desk ticket updated successfully', 'success')
        except Exception as e:
            print(e)
            flash('Error updating help desk ticket', 'danger')

        return redirect(url_for('view_help_desk_tickets'))

#  based on session["CustomerId"] it fetch the status in view_user_tickets.html from help_desk_tickets column based on user_id
@app.route("/view_user_tickets")
def view_user_tickets():
    try:
        user_id = session["Customerid"]
        cur = mysql.connection.cursor()
        cur.execute('SELECT * FROM help_desk_tickets WHERE user_id=%s', [user_id])
        user_tickets = cur.fetchall()
        cur.close()

        return render_template("view_user_tickets.html", user_tickets=user_tickets)

    except Exception as e:
        print(e)
        flash('Error fetching user tickets', 'danger')
        return render_template("user_home.html")  # Redirect to a suitable page if there's an error

# Insert assignment details into assigned_assets_customers table for each selected asset
# Insert assignment details into assigned_assets_customers table for each selected asset
@app.route("/assign_assets", methods=['GET', 'POST'])
def assign_assets():
    if request.method == 'POST':
        if 'assign' in request.form:
            customer_id = request.form["customer_id"]
            asset_ids = request.form.getlist("asset_id[]")

            # Fetch customer details based on customer_id
            cur = mysql.connection.cursor()
            cur.execute("SELECT * FROM customers WHERE customer_id=%s", [customer_id])
            customer_details = cur.fetchone()

            if customer_details:
                try:
                    # Insert assignment details into assigned_assets_customers table for each selected asset
                    for asset_id in asset_ids:
                        # Fetch asset details based on asset_id
                        cur.execute("SELECT asset_name, asset_description FROM it_assets WHERE asset_id=%s", [asset_id])
                        asset_details = cur.fetchone()

                        if asset_details:
                            cur.execute('INSERT INTO assigned_assets_customers (customer_id, asset_id, assignment_date, customer_name, customer_email, customer_address, asset_name, asset_description) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)',
                                        [customer_id, asset_id, datetime.now(), customer_details["customer_name"], customer_details["customer_email"], customer_details["customer_address"], asset_details["asset_name"], asset_details["asset_description"]])

                    mysql.connection.commit()
                    cur.close()

                    flash('Assets assigned successfully', 'success')
                    return redirect(url_for('view_assigned_assets'))  # Redirect to the view_assigned_assets page
                except Exception as e:
                    print(e)
                    flash('Error assigning assets', 'danger')

    # Fetch existing customer_ids and asset_ids on assign_assets.html page
    cur = mysql.connection.cursor()
    cur.execute("SELECT customer_id, customer_name FROM customers")
    customer_data = cur.fetchall()

    cur.execute("SELECT asset_id, asset_name FROM it_assets")
    asset_data = cur.fetchall()
    cur.close()

    return render_template("assign_assets.html", customer_data=customer_data, asset_data=asset_data)


# Fetch data from the assigned_assets_customers table in view_assigned_assets.html page
@app.route("/view_assigned_assets")
def view_assigned_assets():
    try:
        # Fetch data from the assigned_assets_customers table
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM assigned_assets_customers")
        assigned_assets_data = cur.fetchall()
        cur.close()

        return render_template("view_assigned_assets.html", assigned_assets_data=assigned_assets_data)

    except Exception as e:
        print(e)
        flash('Error fetching assigned assets data', 'danger')

    return render_template("view_assigned_assets.html", assigned_assets_data=[])

# Edit assigned asset and update when we click the update button means it will update page was edit_
@app.route("/edit_assigned_asset/<int:assignment_id>", methods=['GET', 'POST'])
def edit_assigned_asset(assignment_id):
    if request.method == 'POST':
        if 'update' in request.form:
            try:
                # Extract form data
                customer_id = request.form["customer_id"]
                asset_id = request.form["asset_id"]
                asset_name = request.form["asset_name"]
                asset_description = request.form["asset_description"]
                # Add additional fields as needed
                # ...

                # Update the assigned_assets_customers table
                cur = mysql.connection.cursor()
                cur.execute('UPDATE assigned_assets_customers SET customer_id=%s, asset_id=%s, asset_name=%s, asset_description=%s WHERE assignment_id=%s',
                            [customer_id, asset_id, asset_name, asset_description, assignment_id])
                mysql.connection.commit()
                cur.close()

                flash('Asset updated successfully', 'success')
                return redirect(url_for('view_assigned_assets'))

            except Exception as e:
                print(e)
                flash('Error updating asset', 'danger')

    # Fetch existing data for the specified assignment_id and render the edit page
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM assigned_assets_customers WHERE assignment_id=%s", [assignment_id])
    assigned_asset_data = cur.fetchone()
    cur.close()

    return render_template("edit_assigned_asset.html", assigned_asset_data=assigned_asset_data)

# Delete assigned asset in view_assigned_assets.html page itself
@app.route("/delete_assigned_asset/<int:assignment_id>", methods=['POST'])
def delete_assigned_asset(assignment_id):
    try:
        # Delete the assigned asset from the assigned_assets_customers table
        cur = mysql.connection.cursor()
        cur.execute('DELETE FROM assigned_assets_customers WHERE assignment_id=%s', [assignment_id])
        mysql.connection.commit()
        cur.close()

        flash('Asset deleted successfully', 'success')
    except Exception as e:
        print(e)
        flash('Error deleting asset', 'danger')

    return redirect(url_for('view_assigned_assets'))

# Add this route after the user_home route Fetch data from the assigned_assets_customers table based on the customer_id
@app.route("/view_assigned_assets_customer")
def view_assigned_assets_customer():
    try:
        # Fetch data from the assigned_assets_customers table based on the customer_id
        customer_id = session.get("Customerid")
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM assigned_assets_customers WHERE customer_id=%s", [customer_id])
        assigned_assets_data_customer = cur.fetchall()
        cur.close()

        return render_template("view_assigned_assets_customer.html", assigned_assets_data_customer=assigned_assets_data_customer)

    except Exception as e:
        print(e)
        flash('Error fetching assigned assets data for the customer', 'danger')

    return render_template("view_assigned_assets_customer.html", assigned_assets_data_customer=[])


@app.route("/user_home")
def user_home():
    return render_template("user_home.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

if(__name__=='__main__'):
    app.secret_key= '123'
    app.run(debug=True)

