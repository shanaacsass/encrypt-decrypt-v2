from flask import Flask,render_template,request,url_for,session,redirect,flash
from flask_mysqldb import MySQL
from flask_bcrypt import Bcrypt
from cryptography.fernet import Fernet

app=Flask(__name__)

app.config["MYSQL_HOST"]="localhost"
app.config["MYSQL_USER"]="root"
app.config["MYSQL_PASSWORD"]=""
app.config["MYSQL_DB"]="register"
app.config["MYSQL_CURSORCLASS"]="DictCursor"
mysql=MySQL(app)
bcrypt = Bcrypt(app)
# cipher text package
key = Fernet.generate_key()
cipher_suite = Fernet(key)
# @app.route("/")
# def index():
#     cur = mysql.connection.cursor()
#     cur.execute("select * from admin")
#     result = cur.fetchall()
#     return '<h1>'+str(result[0]["aid"])+'</h1>'
@app.route("/", methods=['GET','POST'])
def index():
    if 'alogin' in request.form:
        if request.method == 'POST':
            # aname = request.form["aname"]
            aemail = request.form["aemail"]
            apass = request.form["apass"]
            try:
                cur = mysql.connection.cursor()
                cur.execute("select * from admin where aemail=%s and apass=%s", [aemail, apass])
                res = cur.fetchone()
                if res:
                    session["aname"] = res["aname"]
                    session["aid"] = res["aid"]
                    return redirect(url_for('admin_home'))
                else:
                    return render_template("index.html")
            except Exception as e:
                print(e)
            finally:
                mysql.connection.commit()
                cur.close()
    elif 'register' in request.form:
        if request.method == 'POST':
            uname = request.form["uname"]
            password = request.form["upass"]
            hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')  # Hash the password
            age = request.form["age"]
            address = request.form["address"]
            contact = request.form["contact"]
            mail = request.form["mail"]
            cur = mysql.connection.cursor()
            cur.execute('insert into users (name,password,age,address,contact,mail) values(%s,%s,%s,%s,%s,%s)', [uname, hashed_password, age, address, contact, mail])         
            mysql.connection.commit()
        return render_template("index.html")
    
    elif 'ulogin' in request.form:
        if request.method == 'POST':
            uname = request.form["uname"]
            upass = request.form["upass"]
            try:
                cur = mysql.connection.cursor()
                cur.execute("SELECT * FROM users WHERE name=%s", [uname])
                res = cur.fetchone()
                if res and bcrypt.check_password_hash(res["password"], upass):
                    session["name"] = res["name"]
                    session["pid"] = res["pid"]
                    return redirect(url_for('user_home'))
                else:
                    return render_template("index.html")
            except Exception as e:
                print(e)
            finally:
                cur.close()
                mysql.connection.commit()

    return render_template("index.html")


@app.route("/user_profile")
def user_profile():
    cur = mysql.connection.cursor()
    id=session["pid"]
    qry = "select * from users where pid=%s"
    cur.execute(qry,[id])
    data = cur.fetchall()
    cur.close()
    count = cur.rowcount
    if count == 0:
        flash("Users Not Found...!!!", "danger")
    else:
        return render_template("user_profile.html",res=data)

@app.route("/update_user",methods=['GET','POST'])
def update_user():
    if request.method == 'POST':
        name = request.form['name']
        password = request.form['password']
        age = request.form['age']
        address = request.form['address']
        contact = request.form['contact']
        mail = request.form['mail']
        pid=session["pid"]
        cur = mysql.connection.cursor()
        cur.execute("update users set name=%s,password=%s,age=%s,address=%s,contact=%s,mail=%s where pid=%s",[name,password,age,address,contact,mail,pid])#white colour is variable name which was stored the values and yellow colour is column name 
        mysql.connection.commit()
        flash('User Updated Successfully', 'success')
        return redirect(url_for('user_profile'))
    return render_template("user_profile.html")




@app.route("/admin_home", methods=['GET', 'POST'])
def admin_home():
    adminname = session.get("aname")

    if request.method == 'POST' and 'register' in request.form:
        # Handle user registration
        Customername = request.form["customername"]
        Customeremail = request.form["customeremail"]
        Customerpassword = request.form["customerpassword"]

        try:
            # Hash the password
            Customerhashedpassword = bcrypt.generate_password_hash(Customerpassword).decode('utf-8')

            # Insert the new user into the admin table
            cur = mysql.connection.cursor()
            cur.execute('INSERT INTO customers (customer_name, customer_email, customer_password) VALUES (%s, %s, %s)', [Customername, Customeremail, Customerhashedpassword])
            mysql.connection.commit()
            cur.close()

            flash('User registered successfully', 'success')
            return redirect(url_for('admin_home'))

        except Exception as e:
            print(e)
            flash('Error registering user', 'danger')

    return render_template("admin_home.html", aname=adminname)

# admin view existing customers from customers table
@app.route("/view_users")
def view_users():
    cur = mysql.connection.cursor()
    qry = "select * from customers"
    cur.execute(qry)
    data = cur.fetchall()
    cur.close()
    count = cur.rowcount
    if count == 0:
        flash("Users not found...!!!", "danger")
    return render_template("view_users.html",res=data)

# admin delete customers data 
@app.route("/delete_users/<string:Customerid>", methods=['GET', 'POST'])
def delete_users(Customerid):
    cur = mysql.connection.cursor()
    cur.execute("delete from customers where customer_id=%s", [Customerid])
    mysql.connection.commit()
    flash("Users Deleted Successfully", "danger")
    return redirect(url_for("view_users"))

# admin update customers modal code
@app.route("/update_user_data/<string:Customerid>", methods=['POST'])
def update_user_data(Customerid):
    print("Updating user data for Customer ID:", Customerid)

    if request.method == 'POST':
        # Fetch data from the form
        update_name = request.form["update_name"]
        update_age = request.form["update_age"]
        update_address = request.form["update_address"]
        update_email = request.form["update_email"]
        update_password = request.form["update_password"]

        try:
            cur = mysql.connection.cursor()

            # Check if the password field is not empty, then update the password
            if update_password:
                hashed_password = bcrypt.generate_password_hash(update_password).decode('utf-8')
                cur.execute('UPDATE customers SET customer_name=%s, customer_age=%s, customer_address=%s, customer_email=%s, customer_password=%s WHERE customer_id=%s',
                            [update_name, update_age, update_address, update_email, hashed_password, Customerid])
            else:
                cur.execute('UPDATE customers SET customer_name=%s, customer_age=%s, customer_address=%s, customer_email=%s WHERE customer_id=%s',
                            [update_name, update_age, update_address, update_email, Customerid])

            mysql.connection.commit()
            cur.close()

            print('User updated successfully')
            flash('User updated successfully', 'success')
        except Exception as e:
            print(e)
            print('Error updating user')
            flash('Error updating user', 'danger')

    return redirect(url_for('view_users'))



@app.route("/user_home")
def user_home():
    return render_template("user_home.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

if(__name__=='__main__'):
    app.secret_key= '123'
    app.run(debug=True)

