from cryptography.fernet import Fernet

# Assuming you have the Fernet instance created with the appropriate key (similar to what you did in other parts of your code)
# fernet = Fernet(app.config['SECRET_KEY'])  # Assuming 'SECRET_KEY' is your encryption key

@app.route("/update_ticket/<int:ticket_id>")
def update_ticket(ticket_id):
    try:
        # Fetch the ticket details based on the ticket ID
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM help_desk_tickets WHERE ticket_id=%s", [ticket_id])
        ticket_details = cur.fetchone()

        # Decrypt ticket details using the encryption key
        encryption_key = ticket_details['encryption_key']
        fernet = Fernet(encryption_key)

        # Decrypt ticket details and update the 'ticket_details' dictionary
        decrypt_issue_description = fernet.decrypt(ticket_details["issue_description"].encode()).decode('utf-8')
        decrypt_status = fernet.decrypt(ticket_details["status"].encode()).decode('utf-8')
        decrypt_priority = fernet.decrypt(ticket_details["priority"].encode()).decode('utf-8')
        decrypt_timestamp = fernet.decrypt(ticket_details["timestamp"].encode()).decode('utf-8')

        ticket_details.update({
            "issue_description": decrypt_issue_description,
            "status": decrypt_status,
            "priority": decrypt_priority,
            "timestamp": decrypt_timestamp
        })

        cur.close()

        return render_template("update_ticket.html", ticket_details=ticket_details)

    except Exception as e:
        print(e)
        flash('Error fetching and decrypting ticket details', 'danger')

    return render_template("update_ticket.html", ticket_details=None)
