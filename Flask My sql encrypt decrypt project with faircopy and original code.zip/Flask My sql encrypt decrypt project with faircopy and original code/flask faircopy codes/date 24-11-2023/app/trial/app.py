# Add this route after the user_home route Fetch data from the assigned_assets_customers table based on the customer_id
@app.route("/view_assigned_assets_customer")
def view_assigned_assets_customer():
    try:
        # Fetch data from the assigned_assets_customers table based on the customer_id
        customer_id = session.get("Customerid")
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM assigned_assets_customers WHERE customer_id=%s", [customer_id])
        assigned_assets_data_customer = cur.fetchall()

        # Decrypt asset details using the encryption key
        decrypted_assets_data = [] #Iterate over the fetched data, decrypt the asset name and description for each entry, and store the decrypted values in a list (decrypted_assets_data).
        for assigned_asset_customer in assigned_assets_data_customer:
            encryption_key = assigned_asset_customer['encryption_key'] #load the encryption_key column value
            fernet = Fernet(encryption_key) # Create a Fernet object with the existing encryption key

            # Decrypt asset details and store in variables
            decrypted_asset_name = fernet.decrypt(assigned_asset_customer["asset_name"].encode()).decode('utf-8')
            decrypted_asset_description = fernet.decrypt(assigned_asset_customer["asset_description"].encode()).decode('utf-8')

            # Add the decrypted values to the list
            decrypted_assets_data.append({
                "assignment_id": assigned_asset_customer["assignment_id"],
                "asset_id": assigned_asset_customer["asset_id"],
                "asset_name": decrypted_asset_name,
                "asset_description": decrypted_asset_description,
                "assignment_date": assigned_asset_customer["assignment_date"]
                # Add additional columns as needed
            })

        cur.close()

        return render_template("view_assigned_assets_customer.html", assigned_assets_data_customer=decrypted_assets_data)

    except Exception as e:
        print(e)
        flash('Error fetching assigned assets data', 'danger')

    # Render the template with None values in case of an error
    return render_template("view_assigned_assets_customer.html", assigned_assets_data_customer=None)