-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2023 at 01:36 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `aname` varchar(250) NOT NULL,
  `apass` varchar(250) NOT NULL,
  `aemail` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `aname`, `apass`, `aemail`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com'),
(2, 'shana', '$2b$12$BtynsNvmZVhe29GtXZNWR.ba5/3kcKheNFvH1fvLyHx9bLP5LLh5m', 'shana@gmail.com'),
(3, 'stark', '$2b$12$V1z5mZmeWXC5XfjwUDR50.qp4tGxsEbAlkCgdixSBdFmniCYt8r.O', 'stark@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `assigned_assets_customers`
--

CREATE TABLE `assigned_assets_customers` (
  `assignment_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `asset_name` varchar(255) NOT NULL,
  `asset_description` varchar(255) NOT NULL,
  `assignment_date` varchar(250) DEFAULT NULL,
  `customer_name` varchar(500) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `customer_address` varchar(255) DEFAULT NULL,
  `encryption_key` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assigned_assets_customers`
--

INSERT INTO `assigned_assets_customers` (`assignment_id`, `customer_id`, `asset_id`, `asset_name`, `asset_description`, `assignment_date`, `customer_name`, `customer_email`, `customer_address`, `encryption_key`) VALUES
(1, 1, 1, 'gAAAAABlXyRF5I6GA8ZeZBTUxje19tAz7WTPz1eqdp_NlGfJzRyOG8kWDpRaxFhRznTDxBMu0BGuc5sCshvOGBoRZAsNFZk9uA==', 'gAAAAABlXyRF6F5keWr7d698TtVyZEqbEP1o_yEa4UTwuJsRfGcBn3FldZiKyRHwMs-dnuCiUCdEHESHtk8kBOfkoo8hHolCPjIcv3-iAWvRcpGoJ2riIAM=', '2023-11-23 15:37:01.277817', 'gAAAAABlXyRF3-XgCgneDRc66W5G60Xiw0X8TcEDJAHcuGZtTKdml7Xp7GSxBVzELESwXu3YyKbCtxxhLobxRsq542MNf0Uttw==', 'gAAAAABlXyRFP7rfW2B7F2DVwOWbFDWTl8Apjdv72hDjz4fq2UBHJ96Sy4tGMlWgiq3yap4zy5yv_MLuIHgmvbeQ0VqDt68I9MCm43TorLYTwROOwB4tSlM=', 'gAAAAABlXyRFD72WM2hqdP5AVzJmLIZjdqIriDEXaPaqUcNifmVqDn-L-ZrTu2Oyft0xIcjVHT1rUKQ1a_HSKAPjmXq2VK4U9g==', 'BLHHNAccpW6LZAxz_Vv2iWWbF7M-716aLgVEcDIY4YA='),
(2, 1, 2, 'gAAAAABlXyRFK9CW8yXSK6ncODEmJfo_xDBoC_Z_h5b_2_KC82irm3cx5mbc1Wwgt3S9f_j6TLrNqoSs49zkLZikl0MFoolsNw==', 'gAAAAABlXyRFSF0rUXjTTcEB341I_LARdxpzmTGlVCHLqfB6Av3I1mqcmt1epxxNn_W6-xuUD1Q8ohc9IOsyodeBmTAdbU2IlQ==', '2023-11-23 15:37:01.279811', 'gAAAAABlXyRF3-XgCgneDRc66W5G60Xiw0X8TcEDJAHcuGZtTKdml7Xp7GSxBVzELESwXu3YyKbCtxxhLobxRsq542MNf0Uttw==', 'gAAAAABlXyRFP7rfW2B7F2DVwOWbFDWTl8Apjdv72hDjz4fq2UBHJ96Sy4tGMlWgiq3yap4zy5yv_MLuIHgmvbeQ0VqDt68I9MCm43TorLYTwROOwB4tSlM=', 'gAAAAABlXyRFD72WM2hqdP5AVzJmLIZjdqIriDEXaPaqUcNifmVqDn-L-ZrTu2Oyft0xIcjVHT1rUKQ1a_HSKAPjmXq2VK4U9g==', 'BLHHNAccpW6LZAxz_Vv2iWWbF7M-716aLgVEcDIY4YA=');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_password` varchar(255) NOT NULL,
  `customer_age` varchar(255) NOT NULL,
  `customer_address` varchar(255) NOT NULL,
  `encryption_key` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_email`, `customer_password`, `customer_age`, `customer_address`, `encryption_key`) VALUES
(1, 'gAAAAABlXveS5w_mOVDCneBeIKVehNO6ygyaa2-YilOl_mWkRvbbaBDE9D4xfkfJwn1Zp8NNPn4nU96dxYlJH-wHAAW2baQZXQ==', 'customer@gmail.com', '$2b$12$tTTqxwk0lks5Ipb3HBn8heNhkWMohHCISd2qlJJurdmI64sVLvXI.', 'gAAAAABlXveS_wNgyXf_UjscIB5i-NUzvMK9XjxuBvU5FgJReizdBlVKCSnqK1jm84dTcCgbMiweWIYMtIgvpsiydhU23RLN2A==', 'gAAAAABlXveS0_F2wO_0uyyWg7grgkre0-mDF6Wp-oIcsvKfVz-WS-0KbfT79cZAdmDdivLrQXUCQoz0Ydp4gpWnVLIj29WWFQ==', 'dF9OkRlNnWQg8FwUCMtJ1OsLmeGmbKYa1y9x8tQhCq0='),
(2, 'gAAAAABlYCX4E25kMeligbhAq2GRux02n77n0nWqEyr_TDzMVEdSNqP_es74mijuhH9KE7KrpmR-jcZvgsIp_SNqVFCnmNlzEw==', 'shana@gmail.com', '$2b$12$bORHZPoH6hjLNlUzsLQare29tg1heoOYnau1EBggUgq2y51E5NZ9e', 'gAAAAABlYCX4n9RLmZyQxv1mJq7eNc1bv3n1J2F6RGLAnok4mBKlXzdfr16SuKFO3r6Vm95S3r_lSmQDkPUw93q1Hj2pM2WNUg==', 'gAAAAABlYCX4uhPN9R-soGEpfJ_V7dt9YvVzXisMT8y1zY5vNBpr7ykyX_Xauuu63hY17WarE43mLt9sXVlR0PsRn3Myc01VEg==', 'mW70Vr7QVO8wHy0GbOorRT-4MC0tRWQ8T2bXSGjh8dU='),
(3, 'gAAAAABlXzkvZK3Q5klkr5CNhogqyz6qz81PJx_AsxKA3O70t072eZvNq6jrx2Y6YjKchPcZULanVXbgCZgR-ccXggM3Ddz5AA==', 'tony@gmail.com', '$2b$12$sQzw2Ro/15diV7S8tWYKdeRs9OHFgFO7jPBE6bb73/lztl8.FHajS', '', '', 'P-fow3C3svdLvHGgaSwVcL0JUZKaaRK8b7F2b_40fKk=');

-- --------------------------------------------------------

--
-- Table structure for table `help_desk_tickets`
--

CREATE TABLE `help_desk_tickets` (
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `issue_description` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `priority` varchar(300) DEFAULT NULL,
  `timestamp` varchar(250) NOT NULL,
  `encryption_key` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `help_desk_tickets`
--

INSERT INTO `help_desk_tickets` (`ticket_id`, `user_id`, `issue_description`, `status`, `priority`, `timestamp`, `encryption_key`) VALUES
(4, 1, 'gAAAAABlYH0GXwYHsyi1AmImFemaRo-JhOtngzGha1J2-uQopnDlUq69FpjLDRfrKXaRp044CqV1G4gecE4UMeuHwAm-bFCGMQ==', 'gAAAAABlYH0GX_pXiXQBmfMs-OGpJB4S0QiKLgqzfI49ghbhpOGivL7RCfECZ49QlBLml9Xq2CUF1BD2YCtV1ipnbRaCkR3OIQ==', 'gAAAAABlYH0G1stUsWyoSZfqaaEJCz-4VOCdp9Yt8Vha_m621-nS8l9mV0pmSRtIgb2Iy2VETtrmIR66vqnD5oo6JButYwujUQ==', 'gAAAAABlYH0GgIgieyzX-TSVDHabDLb9Ff-YhMGSqyIvyc-gezCjIiMn0R5ZSMgMsFz22ZSPXS71-Vx4xCKqJbEk7NrtP2euWZXIZYZxiBJx5dpTDzLpdX8=', 'jxEB8c9Tf4-GGUn1LykffthApCscKjWkC9hotMW9ISI='),
(5, 3, 'gAAAAABlYHEIo6a7h8cJMPPloPtreV93WNte7-LJumlflu2HhQD8uC-OUzLxaOPTRd7yGRsWqqmn3LqlzZT2MC1Vm2IZXa8tjpP-5u5GfDR0atkp9JuDohQ=', 'gAAAAABlYHEI1SPVCexGW9pmf7Bq8O1bH6EEkAIwfqefUI1ZpADR5NKA8VrjQzvULPh5oyGP84QOikkpZ2HXaU8XZvgYUiy1UA==', 'gAAAAABlYHEIVyCeJZNfZuQaZFFWGcxOgfzcVsvR20iV1v1jLWZcEbrYAfxV2qxG841nOQ-lQQOGGsRpIzC64ZBgRvSORXiGWw==', 'gAAAAABlYHEILxUyTUmr_ovME4jBZj_TiH54Te8pVvTMWghqs2M2X7nBfqW3nnSyJtXIDJGz1lrpNrxJ91mvB4LLkGlrEscJh81yjwbPTJVFqrWiheWHbm4=', 'nUgpBRRak3DKVDJw4orFofPkuD-HoyC7fJmL5T-WgUE=');

-- --------------------------------------------------------

--
-- Table structure for table `it_assets`
--

CREATE TABLE `it_assets` (
  `asset_id` int(11) NOT NULL,
  `asset_name` varchar(255) NOT NULL,
  `asset_description` varchar(255) DEFAULT NULL,
  `purchase_date` varchar(250) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `encryption_key` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `it_assets`
--

INSERT INTO `it_assets` (`asset_id`, `asset_name`, `asset_description`, `purchase_date`, `location`, `encryption_key`) VALUES
(1, 'gAAAAABlXfCnrDFKa5ceGCRSqJ2ZT6ukHWtceEk4rYXfXEhM7MIxZExn8tWFc0EIq27BtShwcpdnvsgJU28lOrmmG-IbpiKDfA==', 'gAAAAABlXfCnccKE-_sgCiQut-fQ56hh4MYVBdKivVwauVsxDRBPaTLC0mS1DpOZ5S_yY0K9yWKKmYtE1Dz_By1tcO6sTP6mBRNdRW2FTbJH1MuzmWQSCH4=', 'gAAAAABlXfCnzO6GBu-pRyLKJ0RYiStLH2t2X37eGAjDTR8wZ15fOqnMPDCX-w-YOlXmcwO8XOLHnzq_ClrzjjIJK64-jz6lGg==', 'gAAAAABlXfCnKsGHYCRWP9PsYEOX1U1dNsnKV8leJo3nXSk653AS-MIJ3uByGqdn66ZzTEuneJuLqRaz_WqYsA7JuUwBGmOKxA==', '6UDfhKDtcurHcvSJLOl2ISne9zaW8DeF_KMMO5YVSLc='),
(2, 'gAAAAABlXdQ3B65uUIRPv5ai2BLPOsyltgJVjnGKgImaX2pyCcb48QDiY0HolforzKraLaENtEHTTKzhltad_pqNvSXAutsGZw==', 'gAAAAABlXdQ3hylgSQwzTD5peS8wx2Lo-9EavRW09SISfX6pWa5q1-PlqGoyMvxKou5gYu0SCPxHoJWMrVqgOy1KX5A7cuQGEg==', 'gAAAAABlXdQ3a3Iwa1pTFzbfwNbSJT6op1n51T4AssViZMXNIJr1v180kjTNY36P0GEjvseCaFersaDohNewZGTCiioOfwuHHg==', 'gAAAAABlXdQ3usRqgP7ATRdS1V5MFVL32vIWTLxqxslGoFOKj3AtI58oZNB1dzgyXBZ-03ylD4e2kSOQjXNacUUdGHqZSx6Low==', '_ZU53qS_2fdBJo6RIORWHhuLkP2VVnMU_UPIIuQqFYA=');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `pid` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `password` varchar(250) NOT NULL,
  `age` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `contact` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `assigned_assets_customers`
--
ALTER TABLE `assigned_assets_customers`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `help_desk_tickets`
--
ALTER TABLE `help_desk_tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `it_assets`
--
ALTER TABLE `it_assets`
  ADD PRIMARY KEY (`asset_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `assigned_assets_customers`
--
ALTER TABLE `assigned_assets_customers`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `help_desk_tickets`
--
ALTER TABLE `help_desk_tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `it_assets`
--
ALTER TABLE `it_assets`
  MODIFY `asset_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
